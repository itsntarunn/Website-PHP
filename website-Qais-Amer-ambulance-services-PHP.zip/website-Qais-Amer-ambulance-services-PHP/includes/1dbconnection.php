<?php
$con = mysqli_connect("sql110.infinityfree.com", "if0_38079789", "justlikeA1", "if0_38079789_ccbd_ambulance");

if(mysqli_connect_errno()){
    echo "Connection Fail: " . mysqli_connect_error();
}
?>
